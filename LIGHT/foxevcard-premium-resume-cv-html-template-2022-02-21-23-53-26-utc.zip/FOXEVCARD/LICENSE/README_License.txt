 All other parts of the theme including, but not limited to the CSS code, images, and design are licensed according to the license purchased. Read about licensing details here: 

Read more about licensing here: http://themeforest.net/licenses